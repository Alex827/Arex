************************************

Installer for MSDOS and Windows

LSI Corporation SAS2FLASH Release

************************************
=============================
Contents-
=============================
Installer for DOS(SAS2FLSH)    :  \sas2flash_dos_rel\sas2flsh                   Version no:20.00.00.00     Release date:18-SEP-14 
Installer for x86(SAS2FLASH)   :  \sas2flash_win_x86_rel\sas2flash              Version no:20.00.00.00     Release date:18-SEP-14 
Installer for x64(SAS2FLASH)   :  \sas2flash_win_x64_rel\sas2flash              Version no:20.00.00.00     Release date:18-SEP-14 
Installer for ia64(SAS2FLASH)  :  \sas2flash_win_ia64_rel\sas2flash             Version no:20.00.00.00     Release date:18-SEP-14 
README_FOR_Installer_P20_MSDOS_and_Windows.txt
SAS2Flash_ReferenceGuide.pdf
SAS2FLASH_Phase20.0-20.00.00.00.pdf



Installation:
=============

SAS2FLASH is stand-alone binary and can be executed from any location on a file system.For more details on installer please refer to the SAS2FLASH User manual included in this package.


